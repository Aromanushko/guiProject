package albummanager.src;
/** 
 * @author Robert Reid, Anthony Romanushko
 * Class to run project 1
 */
public class RunProject1 {
	public static void main(String args[]) {
		new CollectionManager().run();
	}
}
