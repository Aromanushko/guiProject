package albummanager.src;
/** 
 * @author Robert Reid, Anthony Romanushko
 * enum object class
 */
/**
 * 
 * Genres represented as enums for us in album manager
 *
 */
public enum Genre {
	Classical, Country, Jazz, Pop, Unknown
}
